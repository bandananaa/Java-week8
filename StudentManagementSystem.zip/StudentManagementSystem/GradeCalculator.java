package StudentManagementSystem;

public class GradeCalculator {
    private double grade_math;
    private double grade_science;
    private double grade_english;
    public Student student;

    public double getGrade_math() {
        return grade_math;
    }
    public double getGrade_science() {
        return grade_science;
    }
    public double getGrade_english() {
        return grade_english;
    }
    public void setGrade_math(double grade_math) {
        this.grade_math = grade_math;
    }
    public void setGrade_science(double grade_science) {
        this.grade_science = grade_science;
    }
    public void setGrade_english(double grade_english) {
        this.grade_english = grade_english;
    }

    public void CalculateGrade(int grade_english, int grade_math, int grade_science) {
        int total = grade_english + grade_math + grade_science;
        System.out.println("Total Grade: of "+ student.getName()+ " " + "age "+ student.getAge()+" is " + total);
    }
}
