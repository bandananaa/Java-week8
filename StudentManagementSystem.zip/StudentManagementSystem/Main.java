package StudentManagementSystem;

public class Main {
    public static void main(String[] args) {
        Student s1 = new Student("Bandana", 21);

        GradeCalculator g1 = new GradeCalculator();
        g1.student = s1;

        g1.CalculateGrade(89, 70, 69);
    }
}
